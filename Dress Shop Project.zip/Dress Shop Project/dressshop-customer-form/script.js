document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('customerForm');
  const displayArea = document.getElementById('displayArea');

  form.addEventListener('submit', async function(e) {
    e.preventDefault();

    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Show submitted info immediately
    displayArea.innerHTML = `
      <p><strong>First Name:</strong> ${data.firstName}</p>
      <p><strong>Last Name:</strong> ${data.lastName}</p>
      <p><strong>Gender:</strong> ${data.gender}</p>
      <p><strong>Address:</strong> ${data.address}</p>
      <p><strong>Contact:</strong> ${data.contact}</p>
      <p><strong>Email:</strong> ${data.email}</p>
      <p><strong>Date of Birth:</strong> ${data.dob}</p>
      <p><strong>Username:</strong> ${data.username}</p>
      <p><strong>Marketing Preference:</strong> ${data.marketing}</p>
      <p><strong>Message:</strong> ${data.message}</p>
      <hr>
      <p style="color: green;"><strong>✅ Information sent to server...</strong></p>
    `;

    try {
      const res = await fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (result.success) {
        alert('Registration successful!');

        // ✅ Redirect based on Marketing Preference
        if (data.marketing.toLowerCase() === 'email') {
          window.location.href = 'email_mockup.html';
        } else if (data.marketing.toLowerCase() === 'social media') {
          window.location.href = 'social_mockup.html';
        } else {
          window.location.href = '../customer/user_login.html';
        }

      } else {
        alert('Registration failed.');
      }

    } catch (err) {
      console.error(err);
      alert('Error connecting to server.');
    }
  });
});
