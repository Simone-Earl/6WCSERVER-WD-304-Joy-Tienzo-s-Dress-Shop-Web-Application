const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcrypt');


const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));
app.use('/customer', express.static(path.join(__dirname, 'customer')));
app.use('/admin', express.static(path.join(__dirname, 'admin')));

// MongoDB Atlas connection
mongoose.connect(
  'mongodb+srv://Yonar:12345@proj.zlugyxi.mongodb.net/joy_tienzo_shop?retryWrites=true&w=majority'
)
.then(() => console.log('Connected to MongoDB Atlas'))
.catch(err => console.error('MongoDB connection error:', err));

// Schemas
const adminSchema = new mongoose.Schema({
  username: String,
  password: String
}, { collection: 'admin_users' });

const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  address: String,
  gender: String,
  dob: String,
  username: String,
  password: String
}, { collection: 'users' });

const messageSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  message: String,
  marketing: String,
  date: String
}, { collection: 'messages' });


// Models
const Admin = mongoose.model('Admin', adminSchema);
const User = mongoose.model('User', userSchema);
const Message = mongoose.model('Message', messageSchema);
User.collection.createIndex({ username: 1 }, { unique: true });
User.collection.createIndex({ email: 1 });


// Routes

// Fetch all customers
app.get('/api/customers', async (req, res) => {
  try {
    const customers = await User.find(); // <-- use User model, not Customer
    res.json(customers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Fetch all messages
app.get('/api/messages', async (req, res) => {
  try {
    const messages = await Message.find();
    res.json(messages);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin login
app.post('/api/admin_login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const admin = await Admin.findOne({ username, password });
    res.json({ success: !!admin });
  } catch {
    res.status(500).json({ success: false });
  }
});

// Customer registration
app.post('/api/register', async (req, res) => {
  const { firstName, lastName, email, address, gender, dob, username, password, message, marketing } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10); // Hash password before saving

    const user = new User({ firstName, lastName, email, address, gender, dob, username, password: hashedPassword });
    await user.save();

    const msg = new Message({
      firstName, lastName, email, message, marketing, date: new Date().toISOString().split('T')[0]
    });
    await msg.save();

    res.json({ success: true, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false });
  }
});


// User login
app.post('/api/user_login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (!user) return res.json({ success: false });

    const isMatch = await bcrypt.compare(password, user.password);
    if (isMatch) res.json({ success: true, user });
    else res.json({ success: false });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false });
  }
});


// Order Schema
const orderSchema = new mongoose.Schema({
  username: String,
  items: [
    {
      name: String,
      price: String,
      quantity: Number
    }
  ],
  totalPaid: String,
  paymentMode: { type: String, default: 'Cash on Delivery' },
  status: { type: String, default: 'Pending' },
  orderDate: { type: Date, default: Date.now }
}, { collection: 'orders' });


const Order = mongoose.model('Order', orderSchema);

// API route to submit order
app.post('/api/submit_order', async (req, res) => {
  try {
    const { username, items, totalPaid, paymentMode } = req.body;
    const order = new Order({ username, items, totalPaid, paymentMode });
    await order.save();
    res.json({ success: true, orderId: order._id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to save order' });
  }
});

// Fetch orders by username
app.get('/api/orders/:username', async (req, res) => {
  try {
    const { username } = req.params;
    const orders = await Order.find({ username });
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// ✅ Auto or manual order status update route
app.put('/api/orders/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    await Order.findByIdAndUpdate(id, { status });
    res.json({ success: true });
  } catch (err) {
    console.error('Error updating order status:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 🗑️ Delete User Account and Related Data by First Name
app.delete('/api/users/:firstName', async (req, res) => {
  const { firstName } = req.params;

  try {
    // 🧱 Delete the user
    const userResult = await User.deleteOne({ firstName });

    if (userResult.deletedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    // 🧱 Delete related orders
    const orderResult = await Order.deleteMany({ username: firstName });

    // 🧱 Delete related messages by firstName
    const messageResult = await Message.deleteMany({ firstName });

    // 🧱 Delete from customers collection (if it exists)
    try {
      const Customer = mongoose.model('Customer');
      await Customer.deleteMany({ firstName });
    } catch (err) {
      console.warn('⚠️ Customer collection not found or not used, skipping...');
    }

    res.json({
      success: true,
      message: 'User and all related data deleted successfully!',
      deleted: {
        users: userResult.deletedCount,
        orders: orderResult.deletedCount,
        messages: messageResult.deletedCount
      }
    });
  } catch (err) {
    console.error('❌ Error deleting user and related data:', err);
    res.status(500).json({
      success: false,
      message: 'Error deleting user data',
      error: err.message
    });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
